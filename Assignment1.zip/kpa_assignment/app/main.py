from fastapi import FastAPI
from app.routers import kpa_form
from app.database import engine
from app.models import Base

app = FastAPI()
Base.metadata.create_all(bind=engine)

app.include_router(kpa_form.router, tags=["KPA Forms"])
